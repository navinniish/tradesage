import React from 'react';
import { TrendingUp, Radio, Zap } from 'lucide-react';
import { MarketTrend } from '../../types';

interface MarketTrendCardProps {
  trend: MarketTrend;
}

const MarketTrendCard: React.FC<MarketTrendCardProps> = ({ trend }) => {
  const getImpactBadge = () => {
    switch (trend.impactLevel) {
      case 'high':
        return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
      case 'medium':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300';
      case 'low':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center">
          <TrendingUp className="h-5 w-5 text-indigo-500 mr-2" />
          <h3 className="font-medium text-lg text-gray-900 dark:text-white">{trend.name}</h3>
        </div>
        <span className={`text-xs px-2 py-1 rounded-full ${getImpactBadge()}`}>
          {trend.impactLevel.charAt(0).toUpperCase() + trend.impactLevel.slice(1)} Impact
        </span>
      </div>
      
      <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{trend.description}</p>
      
      <div className="mb-3">
        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center mb-2">
          <Radio className="h-4 w-4 mr-1" /> Affected Sectors
        </h4>
        <div className="flex flex-wrap gap-2">
          {trend.affectedSectors.map((sector, index) => (
            <span 
              key={index} 
              className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300"
            >
              {sector}
            </span>
          ))}
        </div>
      </div>
      
      <div className="pt-3 border-t border-gray-100 dark:border-gray-700">
        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center mb-2">
          <Zap className="h-4 w-4 mr-1" /> Market Prediction
        </h4>
        <p className="text-sm text-indigo-600 dark:text-indigo-400">{trend.prediction}</p>
      </div>
    </div>
  );
};

export default MarketTrendCard;