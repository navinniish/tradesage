import React, { useState } from 'react';
import { LineChart, ArrowUpRight, ArrowDownRight, TrendingUp, BarChart } from 'lucide-react';
import { mockStocks } from '../../data/mockData';

const MarketOverview: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const indices = [
    { name: "S&P 500", value: 5284.23, change: 0.75, trend: "up" },
    { name: "NASDAQ", value: 16727.14, change: 1.21, trend: "up" },
    { name: "DOW", value: 38432.69, change: 0.32, trend: "up" },
    { name: "FTSE 100", value: 8142.23, change: -0.45, trend: "down" },
    { name: "NIKKEI 225", value: 38953.12, change: 0.65, trend: "up" }
  ];

  const sectors = [
    { name: "Technology", change: 1.42, trend: "up" },
    { name: "Healthcare", change: 0.75, trend: "up" },
    { name: "Financials", change: -0.23, trend: "down" },
    { name: "Consumer Disc.", change: 0.65, trend: "up" },
    { name: "Energy", change: -1.12, trend: "down" }
  ];

  const gainers = [...mockStocks]
    .sort((a, b) => b.changePercent - a.changePercent)
    .slice(0, 4);
    
  const losers = [...mockStocks]
    .sort((a, b) => a.changePercent - b.changePercent)
    .slice(0, 4);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left Column - Market Indices */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-5 border border-gray-100 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">Market Indices</h2>
          <LineChart className="h-5 w-5 text-blue-600 dark:text-blue-500" />
        </div>
        
        <div className="flex mb-6 overflow-x-auto pb-2 space-x-2">
          {indices.map((index, i) => (
            <button
              key={index.name}
              className={`px-3 py-1.5 text-sm rounded-md whitespace-nowrap ${
                selectedIndex === i 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
              onClick={() => setSelectedIndex(i)}
            >
              {index.name}
            </button>
          ))}
        </div>
        
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            {indices[selectedIndex].value.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h3>
          <div className={`inline-flex items-center text-sm font-medium ${
            indices[selectedIndex].trend === 'up' ? 'text-green-600 dark:text-green-500' : 'text-red-600 dark:text-red-500'
          }`}>
            {indices[selectedIndex].trend === 'up' 
              ? <ArrowUpRight className="h-4 w-4 mr-1" /> 
              : <ArrowDownRight className="h-4 w-4 mr-1" />}
            {indices[selectedIndex].change > 0 ? '+' : ''}{indices[selectedIndex].change}%
          </div>
        </div>
        
        {/* Mock chart - simple placeholder */}
        <div className="h-24 w-full overflow-hidden rounded bg-gray-50 dark:bg-gray-700 mb-4">
          <div className="h-full w-full bg-gradient-to-r from-blue-100 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/20 relative">
            <div className="absolute inset-0 flex items-center justify-center text-gray-400 dark:text-gray-500">
              Chart visualization would appear here
            </div>
          </div>
        </div>
      </div>
      
      {/* Middle Column - Top Gainers */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-5 border border-gray-100 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">Top Gainers</h2>
          <TrendingUp className="h-5 w-5 text-green-600 dark:text-green-500" />
        </div>
        
        <div className="divide-y divide-gray-100 dark:divide-gray-700">
          {gainers.map(stock => (
            <div key={stock.id} className="py-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-900 dark:text-white">{stock.symbol}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">{stock.name}</div>
              </div>
              <div className="text-right">
                <div className="font-medium text-gray-900 dark:text-white">${stock.price.toFixed(2)}</div>
                <div className="flex items-center text-xs font-medium text-green-600 dark:text-green-500">
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                  +{stock.changePercent.toFixed(2)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Right Column - Top Losers */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-5 border border-gray-100 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">Sector Performance</h2>
          <BarChart className="h-5 w-5 text-purple-600 dark:text-purple-500" />
        </div>
        
        <div className="divide-y divide-gray-100 dark:divide-gray-700">
          {sectors.map((sector, index) => (
            <div key={index} className="py-3 flex items-center justify-between">
              <div className="font-medium text-gray-900 dark:text-white">{sector.name}</div>
              <div className={`flex items-center text-sm font-medium ${
                sector.trend === 'up' ? 'text-green-600 dark:text-green-500' : 'text-red-600 dark:text-red-500'
              }`}>
                {sector.trend === 'up' 
                  ? <ArrowUpRight className="h-3 w-3 mr-1" /> 
                  : <ArrowDownRight className="h-3 w-3 mr-1" />}
                {sector.change > 0 ? '+' : ''}{sector.change}%
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6">
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Top Losers</h3>
          <div className="grid grid-cols-2 gap-3">
            {losers.map(stock => (
              <div key={stock.id} className="bg-gray-50 dark:bg-gray-700 rounded-md p-2 text-xs">
                <div className="font-medium text-gray-900 dark:text-white">{stock.symbol}</div>
                <div className="flex items-center text-red-500 mt-1">
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                  {stock.changePercent.toFixed(2)}%
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketOverview;