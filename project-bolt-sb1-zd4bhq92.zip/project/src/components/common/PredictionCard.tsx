import React from 'react';
import { TrendingUp, TrendingDown, Minus, AlertCircle, Clock } from 'lucide-react';
import { StockPrediction } from '../../types';
import { mockStocks } from '../../data/mockData';

interface PredictionCardProps {
  prediction: StockPrediction;
}

const PredictionCard: React.FC<PredictionCardProps> = ({ prediction }) => {
  const stock = mockStocks.find(s => s.id === prediction.stockId);
  
  if (!stock) return null;
  
  const getDirectionIcon = () => {
    switch (prediction.direction) {
      case 'up':
        return <TrendingUp className="h-5 w-5 text-green-500" />;
      case 'down':
        return <TrendingDown className="h-5 w-5 text-red-500" />;
      default:
        return <Minus className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const getDirectionClass = () => {
    switch (prediction.direction) {
      case 'up':
        return 'bg-green-50 border-green-100 dark:bg-green-900/20 dark:border-green-800';
      case 'down':
        return 'bg-red-50 border-red-100 dark:bg-red-900/20 dark:border-red-800';
      default:
        return 'bg-gray-50 border-gray-100 dark:bg-gray-800 dark:border-gray-700';
    }
  };
  
  const getTimeframeLabel = () => {
    switch (prediction.timeframe) {
      case 'short':
        return 'Short-term (1-4 weeks)';
      case 'medium':
        return 'Medium-term (1-3 months)';
      case 'long':
        return 'Long-term (3+ months)';
      default:
        return 'Unknown timeframe';
    }
  };
  
  const getConfidenceColor = () => {
    if (prediction.confidenceScore >= 0.8) return 'text-green-600 dark:text-green-400';
    if (prediction.confidenceScore >= 0.6) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  return (
    <div className={`rounded-lg border p-4 ${getDirectionClass()}`}>
      <div className="flex justify-between items-start mb-3">
        <div>
          <div className="flex items-center">
            {getDirectionIcon()}
            <h3 className="font-medium text-lg text-gray-900 dark:text-white ml-2">{stock.symbol}</h3>
            <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">{stock.name}</span>
          </div>
        </div>
        <div className="flex items-center">
          <div className={`text-sm font-medium ${getConfidenceColor()}`}>
            {Math.round(prediction.confidenceScore * 100)}% confidence
          </div>
        </div>
      </div>
      
      <p className="text-sm text-gray-700 dark:text-gray-300 mb-4">{prediction.prediction}</p>
      
      <div className="mb-3">
        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-1">
          <Clock className="h-4 w-4 mr-2" />
          <span>{getTimeframeLabel()}</span>
        </div>
      </div>
      
      <div className="space-y-2">
        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
          <AlertCircle className="h-4 w-4 mr-1" /> Key Factors
        </h4>
        <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1 pl-6 list-disc">
          {prediction.factors.map((factor, index) => (
            <li key={index}>{factor}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default PredictionCard;