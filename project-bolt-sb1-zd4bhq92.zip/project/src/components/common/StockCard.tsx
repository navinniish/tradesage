import React from 'react';
import { ArrowUp, ArrowDown, Star, BarChart3 } from 'lucide-react';
import { Stock } from '../../types';

interface StockCardProps {
  stock: Stock;
  onAddToWatchlist?: (stockId: string) => void;
  onViewDetails?: (stockId: string) => void;
  isWatchlisted?: boolean;
}

const StockCard: React.FC<StockCardProps> = ({
  stock,
  onAddToWatchlist,
  onViewDetails,
  isWatchlisted = false
}) => {
  const isPositive = stock.change >= 0;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 p-4 border border-gray-100 dark:border-gray-700">
      <div className="flex justify-between items-start mb-2">
        <div>
          <h3 className="font-medium text-lg text-gray-900 dark:text-white">{stock.symbol}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">{stock.name}</p>
        </div>
        <button 
          onClick={() => onAddToWatchlist?.(stock.id)}
          className="text-gray-400 hover:text-amber-500 dark:text-gray-500 dark:hover:text-amber-400 transition-colors duration-200"
          aria-label={isWatchlisted ? "Remove from watchlist" : "Add to watchlist"}
        >
          <Star className={`h-5 w-5 ${isWatchlisted ? 'fill-amber-500 text-amber-500' : ''}`} />
        </button>
      </div>
      
      <div className="flex items-center justify-between mt-3">
        <span className="text-xl font-semibold text-gray-900 dark:text-white">
          ${stock.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </span>
        <div className={`flex items-center text-sm ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          {isPositive ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
          <span className="font-medium">
            {isPositive ? '+' : ''}{stock.change.toFixed(2)} ({isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%)
          </span>
        </div>
      </div>
      
      <div className="flex items-center justify-between mt-4 text-xs text-gray-500 dark:text-gray-400">
        <div>
          <p>Vol: {(stock.volume / 1000000).toFixed(1)}M</p>
          <p>P/E: {stock.pe.toFixed(2)}</p>
        </div>
        <div>
          <p>{stock.sector}</p>
          {stock.dividend > 0 && <p>Div: {stock.dividend.toFixed(2)}%</p>}
        </div>
      </div>
      
      <button
        onClick={() => onViewDetails?.(stock.id)}
        className="w-full mt-4 flex items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 dark:bg-gray-700 dark:hover:bg-gray-600 text-blue-600 dark:text-blue-400 py-2 rounded-md text-sm font-medium transition-colors duration-200"
      >
        <BarChart3 className="h-4 w-4" /> View Details
      </button>
    </div>
  );
};

export default StockCard;