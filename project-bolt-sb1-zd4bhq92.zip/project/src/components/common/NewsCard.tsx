import React from 'react';
import { ExternalLink, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { NewsItem } from '../../types';
import { formatDistanceToNow } from '../../utils/formatters';

interface NewsCardProps {
  news: NewsItem;
}

const NewsCard: React.FC<NewsCardProps> = ({ news }) => {
  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'negative':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      default:
        return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const getSentimentClass = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400';
      case 'negative':
        return 'bg-red-50 text-red-700 dark:bg-red-900/30 dark:text-red-400';
      default:
        return 'bg-gray-50 text-gray-700 dark:bg-gray-700 dark:text-gray-400';
    }
  };

  const getImpactBadge = (score: number) => {
    if (score >= 8) return 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300';
    if (score >= 5) return 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300';
    return 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300';
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 p-4 border border-gray-100 dark:border-gray-700">
      <div className="flex justify-between items-start mb-3">
        <div className="flex space-x-2">
          <span className={`text-xs px-2 py-1 rounded-full inline-flex items-center ${getSentimentClass(news.sentiment)}`}>
            {getSentimentIcon(news.sentiment)}
            <span className="ml-1 capitalize">{news.sentiment}</span>
          </span>
          <span className={`text-xs px-2 py-1 rounded-full ${getImpactBadge(news.impactScore)}`}>
            Impact: {news.impactScore}/10
          </span>
        </div>
        <span className="text-xs text-gray-500 dark:text-gray-400">
          {formatDistanceToNow(new Date(news.publishedAt))}
        </span>
      </div>
      
      <h3 className="font-medium text-base text-gray-900 dark:text-white mb-2">{news.title}</h3>
      <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">{news.summary}</p>
      
      <div className="flex justify-between items-center mt-2">
        <span className="text-xs text-gray-500 dark:text-gray-400">Source: {news.source}</span>
        <a 
          href={news.url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
        >
          Read More <ExternalLink className="h-3 w-3 ml-1" />
        </a>
      </div>
    </div>
  );
};

export default NewsCard;