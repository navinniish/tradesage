import React from 'react';
import { FileText, Download, TrendingUp, Wallet, Building } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import { jsPDF } from 'jspdf';

// Move the client initialization inside the component to ensure environment variables are loaded
const FinancialReports: React.FC = () => {
  const supabase = createClient(
    import.meta.env.VITE_SUPABASE_URL ?? '',
    import.meta.env.VITE_SUPABASE_ANON_KEY ?? ''
  );

  const downloadPDF = async (type: string) => {
    const doc = new jsPDF();
    
    // Example data - In production, this would come from your database
    if (type === 'mf') {
      doc.text('Mutual Fund Statement', 20, 20);
      doc.text('Account Balance: $50,000', 20, 30);
      doc.text('Total Returns: 12%', 20, 40);
    } else if (type === 'bank') {
      doc.text('Bank Statement', 20, 20);
      doc.text('Account Number: XXXX-XXXX-1234', 20, 30);
      doc.text('Balance: $25,000', 20, 40);
    }
    
    doc.save(`${type}-statement.pdf`);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Mutual Fund Statement */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <TrendingUp className="h-6 w-6 text-blue-500 mr-2" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Mutual Fund Statement</h3>
            </div>
            <button
              onClick={() => downloadPDF('mf')}
              className="flex items-center text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
            >
              <Download className="h-5 w-5 mr-1" />
              Download
            </button>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Complete statement of your mutual fund investments and returns
          </p>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Last updated: {new Date().toLocaleDateString()}
          </div>
        </div>

        {/* Bank Statement */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Wallet className="h-6 w-6 text-green-500 mr-2" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Bank Statement</h3>
            </div>
            <button
              onClick={() => downloadPDF('bank')}
              className="flex items-center text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
            >
              <Download className="h-5 w-5 mr-1" />
              Download
            </button>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Monthly bank statement with all transactions
          </p>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Last updated: {new Date().toLocaleDateString()}
          </div>
        </div>

        {/* Company Reports */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Building className="h-6 w-6 text-purple-500 mr-2" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Company Reports</h3>
            </div>
            <button
              onClick={() => downloadPDF('company')}
              className="flex items-center text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
            >
              <Download className="h-5 w-5 mr-1" />
              Download
            </button>
          </div>
          <div className="space-y-4">
            <div className="border-b border-gray-100 dark:border-gray-700 pb-4">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">P/E Ratio</h4>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">28.5x</div>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white">Available Reports</h4>
              <div className="space-y-2">
                <button className="flex items-center w-full text-left p-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700">
                  <FileText className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Balance Sheet</span>
                </button>
                <button className="flex items-center w-full text-left p-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700">
                  <FileText className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Profit & Loss Statement</span>
                </button>
                <button className="flex items-center w-full text-left p-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700">
                  <FileText className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Annual Report</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialReports;