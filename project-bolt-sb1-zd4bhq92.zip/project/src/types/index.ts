export interface Stock {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  high52Week: number;
  low52Week: number;
  pe: number;
  dividend: number;
  sector: string;
  industry: string;
}

export interface StockPrediction {
  stockId: string;
  confidenceScore: number;
  direction: 'up' | 'down' | 'stable';
  prediction: string;
  factors: string[];
  timeframe: 'short' | 'medium' | 'long';
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  url: string;
  publishedAt: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  relatedStocks: string[];
  impactScore: number;
}

export interface WatchlistItem {
  id: string;
  stockId: string;
  alertPrice?: number;
  notes?: string;
  addedAt: string;
}

export interface Portfolio {
  holdings: Holding[];
  totalValue: number;
  totalInvestment: number;
  totalReturn: number;
  totalReturnPercent: number;
}

export interface Holding {
  id: string;
  stockId: string;
  quantity: number;
  averageBuyPrice: number;
  currentValue: number;
  returnValue: number;
  returnPercent: number;
  purchaseDate: string;
}

export interface MarketTrend {
  id: string;
  name: string;
  description: string;
  impactLevel: 'high' | 'medium' | 'low';
  affectedSectors: string[];
  prediction: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  profilePicture?: string;
  investmentStyle: 'conservative' | 'moderate' | 'aggressive';
  preferences: {
    sectors: string[];
    riskTolerance: number;
    investmentHorizon: string;
  };
}