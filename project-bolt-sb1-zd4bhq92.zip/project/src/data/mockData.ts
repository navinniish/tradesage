import { Stock, StockPrediction, NewsItem, MarketTrend, Portfolio } from '../types';

export const mockStocks: Stock[] = [
  {
    id: '1',
    symbol: 'AAPL',
    name: 'Apple Inc.',
    price: 187.68,
    change: 1.24,
    changePercent: 0.66,
    volume: 52814253,
    marketCap: 2912518000000,
    high52Week: 198.23,
    low52Week: 124.17,
    pe: 28.92,
    dividend: 0.92,
    sector: 'Technology',
    industry: 'Consumer Electronics'
  },
  {
    id: '2',
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    price: 417.42,
    change: 3.15,
    changePercent: 0.76,
    volume: 18924712,
    marketCap: 3101234000000,
    high52Week: 429.19,
    low52Week: 309.98,
    pe: 34.78,
    dividend: 2.72,
    sector: 'Technology',
    industry: 'Software'
  },
  {
    id: '3',
    symbol: 'TSLA',
    name: 'Tesla, Inc.',
    price: 248.35,
    change: -5.12,
    changePercent: -2.02,
    volume: 77841322,
    marketCap: 790423000000,
    high52Week: 299.29,
    low52Week: 152.37,
    pe: 71.24,
    dividend: 0,
    sector: 'Automotive',
    industry: 'Electric Vehicles'
  },
  {
    id: '4',
    symbol: 'AMZN',
    name: 'Amazon.com, Inc.',
    price: 184.29,
    change: 2.47,
    changePercent: 1.36,
    volume: 34219865,
    marketCap: 1912837000000,
    high52Week: 189.77,
    low52Week: 118.35,
    pe: 56.18,
    dividend: 0,
    sector: 'Consumer Cyclical',
    industry: 'Internet Retail'
  },
  {
    id: '5',
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    price: 125.22,
    change: 3.78,
    changePercent: 3.11,
    volume: 198742631,
    marketCap: 3082940000000,
    high52Week: 140.76,
    low52Week: 39.23,
    pe: 73.21,
    dividend: 0.04,
    sector: 'Technology',
    industry: 'Semiconductors'
  },
  {
    id: '6',
    symbol: 'JPM',
    name: 'JPMorgan Chase & Co.',
    price: 198.75,
    change: -0.87,
    changePercent: -0.44,
    volume: 7821634,
    marketCap: 570123000000,
    high52Week: 205.23,
    low52Week: 152.48,
    pe: 12.08,
    dividend: 4.2,
    sector: 'Financial Services',
    industry: 'Banks'
  },
  {
    id: '7',
    symbol: 'META',
    name: 'Meta Platforms, Inc.',
    price: 502.31,
    change: 8.26,
    changePercent: 1.67,
    volume: 14876235,
    marketCap: 1283742000000,
    high52Week: 531.49,
    low52Week: 276.98,
    pe: 29.34,
    dividend: 0,
    sector: 'Technology',
    industry: 'Internet Content & Information'
  },
  {
    id: '8',
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    price: 162.78,
    change: 1.12,
    changePercent: 0.69,
    volume: 19872364,
    marketCap: 2023456000000,
    high52Week: 169.45,
    low52Week: 120.21,
    pe: 25.12,
    dividend: 0,
    sector: 'Technology',
    industry: 'Internet Content & Information'
  }
];

export const mockPredictions: StockPrediction[] = [
  {
    stockId: '1',
    confidenceScore: 0.82,
    direction: 'up',
    prediction: 'Expected to rise 5-8% over the next month due to strong product lineup and continued services growth.',
    factors: ['New product launches', 'Services revenue growth', 'Strong consumer demand', 'Expanding market share in India'],
    timeframe: 'short'
  },
  {
    stockId: '2',
    confidenceScore: 0.78,
    direction: 'up',
    prediction: 'Projected to gain 3-5% in the coming quarter with steady cloud services growth.',
    factors: ['Azure revenue growth', 'AI integration in products', 'Enterprise contract renewals', 'Strategic acquisitions'],
    timeframe: 'medium'
  },
  {
    stockId: '3',
    confidenceScore: 0.65,
    direction: 'down',
    prediction: 'May face 10-15% decline due to increasing competition and production challenges.',
    factors: ['Production delays', 'Increasing competition', 'Margin pressure', 'Regulatory challenges in China'],
    timeframe: 'short'
  },
  {
    stockId: '5',
    confidenceScore: 0.88,
    direction: 'up',
    prediction: 'Expected to outperform with 12-15% growth driven by AI chip demand and data center expansion.',
    factors: ['AI boom', 'Data center expansion', 'Gaming GPU demand', 'Limited competition in high-end chips'],
    timeframe: 'medium'
  }
];

export const mockNews: NewsItem[] = [
  {
    id: '1',
    title: 'Fed Signals Potential Rate Cuts in Coming Months',
    summary: 'The Federal Reserve indicated it may begin cutting interest rates if inflation continues its downward trend, potentially boosting growth stocks.',
    source: 'Financial Times',
    url: '#',
    publishedAt: '2025-03-15T14:30:00Z',
    sentiment: 'positive',
    relatedStocks: ['1', '2', '4', '5', '7'],
    impactScore: 8
  },
  {
    id: '2',
    title: 'Global Chip Shortage Easing, Supply Chain Improving',
    summary: 'Semiconductor manufacturers report improved production capacity as supply chain constraints ease, potentially benefiting technology companies.',
    source: 'Bloomberg',
    url: '#',
    publishedAt: '2025-03-14T09:15:00Z',
    sentiment: 'positive',
    relatedStocks: ['1', '2', '5', '8'],
    impactScore: 7
  },
  {
    id: '3',
    title: 'Oil Prices Surge Amid Middle East Tensions',
    summary: 'Crude oil prices jumped 5% following escalating geopolitical tensions in the Middle East, potentially impacting global markets and inflation.',
    source: 'Reuters',
    url: '#',
    publishedAt: '2025-03-12T16:45:00Z',
    sentiment: 'negative',
    relatedStocks: ['3', '6'],
    impactScore: 6
  },
  {
    id: '4',
    title: 'Tech Regulations Tightening in EU with New Digital Markets Act',
    summary: 'European Union implements stricter regulations on large tech platforms, potentially impacting revenue streams and business models.',
    source: 'The Economist',
    url: '#',
    publishedAt: '2025-03-10T11:20:00Z',
    sentiment: 'negative',
    relatedStocks: ['1', '2', '4', '7', '8'],
    impactScore: 7
  },
  {
    id: '5',
    title: 'AI Investments Reaching Record Levels in 2025',
    summary: 'Corporate spending on artificial intelligence reaches unprecedented levels, boosting companies with strong AI capabilities and infrastructure.',
    source: 'Wall Street Journal',
    url: '#',
    publishedAt: '2025-03-08T10:30:00Z',
    sentiment: 'positive',
    relatedStocks: ['2', '5', '7', '8'],
    impactScore: 9
  }
];

export const mockMarketTrends: MarketTrend[] = [
  {
    id: '1',
    name: 'AI Revolution',
    description: 'Rapid advancements in artificial intelligence are driving significant investments across multiple sectors.',
    impactLevel: 'high',
    affectedSectors: ['Technology', 'Healthcare', 'Financial Services', 'Manufacturing'],
    prediction: 'Companies with strong AI capabilities will likely outperform the broader market by 15-20% over the next 6-12 months.'
  },
  {
    id: '2',
    name: 'Interest Rate Environment',
    description: 'Shifting monetary policy with potential rate cuts affecting borrowing costs and investment strategies.',
    impactLevel: 'high',
    affectedSectors: ['Financial Services', 'Real Estate', 'Consumer Discretionary', 'Utilities'],
    prediction: 'Financial sector may see improved profit margins of 3-5% while real estate could benefit from lower financing costs.'
  },
  {
    id: '3',
    name: 'Supply Chain Resilience',
    description: 'Companies reorganizing supply chains for resilience rather than pure efficiency after recent disruptions.',
    impactLevel: 'medium',
    affectedSectors: ['Manufacturing', 'Retail', 'Technology', 'Automotive'],
    prediction: 'Companies with diversified supply chains may see 5-7% lower volatility in earnings compared to peers.'
  },
  {
    id: '4',
    name: 'Green Energy Transition',
    description: 'Accelerating shift toward renewable energy sources and sustainable technologies.',
    impactLevel: 'medium',
    affectedSectors: ['Energy', 'Utilities', 'Automotive', 'Manufacturing'],
    prediction: 'Clean energy companies projected to grow revenue at 12-15% annually compared to 2-3% for traditional energy.'
  }
];

export const mockPortfolio: Portfolio = {
  holdings: [
    {
      id: '1',
      stockId: '1',
      quantity: 15,
      averageBuyPrice: 175.32,
      currentValue: 2815.20,
      returnValue: 184.65,
      returnPercent: 7.01,
      purchaseDate: '2024-11-15'
    },
    {
      id: '2',
      stockId: '2',
      quantity: 8,
      averageBuyPrice: 390.45,
      currentValue: 3339.36,
      returnValue: 215.76,
      returnPercent: 6.91,
      purchaseDate: '2024-10-28'
    },
    {
      id: '3',
      stockId: '5',
      quantity: 20,
      averageBuyPrice: 115.78,
      currentValue: 2504.40,
      returnValue: 188.80,
      returnPercent: 8.15,
      purchaseDate: '2024-12-05'
    },
    {
      id: '4',
      stockId: '7',
      quantity: 5,
      averageBuyPrice: 485.23,
      currentValue: 2511.55,
      returnValue: 85.40,
      returnPercent: 3.52,
      purchaseDate: '2025-01-18'
    }
  ],
  totalValue: 11170.51,
  totalInvestment: 10495.90,
  totalReturn: 674.61,
  totalReturnPercent: 6.43
};

export const mockWatchlist = [
  { id: '1', stockId: '3', addedAt: '2025-02-10T08:43:12Z' },
  { id: '2', stockId: '4', alertPrice: 190, addedAt: '2025-02-15T14:22:47Z' },
  { id: '3', stockId: '6', notes: 'Watch for dividend announcement', addedAt: '2025-02-18T09:37:21Z' },
  { id: '4', stockId: '8', alertPrice: 170, addedAt: '2025-02-20T11:15:34Z' }
];