import React, { useState } from 'react';
import { Search, Filter, TrendingUp, SlidersHorizontal, ArrowUpDown } from 'lucide-react';
import StockCard from '../components/common/StockCard';
import { mockStocks } from '../data/mockData';
import { Stock } from '../types';

const StocksExplore: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('alphabetical');
  
  // Extract unique sectors from the stocks data
  const sectors = [...new Set(mockStocks.map(stock => stock.sector))];
  
  // Filter and sort stocks based on user selections
  const filteredStocks = mockStocks.filter(stock => {
    const matchesSearch = stock.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        stock.symbol.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = selectedSector === '' || stock.sector === selectedSector;
    return matchesSearch && matchesSector;
  });
  
  const sortedStocks = [...filteredStocks].sort((a, b) => {
    switch (sortBy) {
      case 'priceAsc':
        return a.price - b.price;
      case 'priceDesc':
        return b.price - a.price;
      case 'changeDesc':
        return b.changePercent - a.changePercent;
      case 'changeAsc':
        return a.changePercent - b.changePercent;
      case 'marketCapDesc':
        return b.marketCap - a.marketCap;
      default:
        return a.symbol.localeCompare(b.symbol);
    }
  });
  
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value);
  };
  
  // Mock watchlist for demo purposes
  const [watchlist, setWatchlist] = useState<string[]>([]);
  
  const handleAddToWatchlist = (stockId: string) => {
    if (watchlist.includes(stockId)) {
      setWatchlist(watchlist.filter(id => id !== stockId));
    } else {
      setWatchlist([...watchlist, stockId]);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Explore Stocks</h1>
      </div>
      
      {/* Search and Filter Section */}
      <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name or symbol..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600"
            />
          </div>
          
          {/* Sector Filter */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 appearance-none"
            >
              <option value="">All Sectors</option>
              {sectors.map(sector => (
                <option key={sector} value={sector}>{sector}</option>
              ))}
            </select>
          </div>
          
          {/* Sort Options */}
          <div className="relative">
            <ArrowUpDown className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <select
              value={sortBy}
              onChange={handleSortChange}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 appearance-none"
            >
              <option value="alphabetical">Alphabetical (A-Z)</option>
              <option value="priceAsc">Price (Low to High)</option>
              <option value="priceDesc">Price (High to Low)</option>
              <option value="changeDesc">% Change (Highest)</option>
              <option value="changeAsc">% Change (Lowest)</option>
              <option value="marketCapDesc">Market Cap (Highest)</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Quick Filters */}
      <div className="flex flex-wrap gap-2">
        <button className="px-4 py-2 rounded-md bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400 dark:hover:bg-blue-800/30 flex items-center gap-2 text-sm font-medium transition-colors duration-200">
          <TrendingUp className="h-4 w-4" /> Top Gainers
        </button>
        <button className="px-4 py-2 rounded-md bg-purple-50 text-purple-600 hover:bg-purple-100 dark:bg-purple-900/20 dark:text-purple-400 dark:hover:bg-purple-800/30 flex items-center gap-2 text-sm font-medium transition-colors duration-200">
          <SlidersHorizontal className="h-4 w-4" /> High Volume
        </button>
        {/* Add more quick filters as needed */}
      </div>
      
      {/* Results Count */}
      <div className="text-sm text-gray-500 dark:text-gray-400">
        Found {sortedStocks.length} stocks
      </div>
      
      {/* Stocks Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {sortedStocks.map(stock => (
          <StockCard 
            key={stock.id} 
            stock={stock} 
            onAddToWatchlist={handleAddToWatchlist}
            onViewDetails={() => console.log('View details:', stock.id)}
            isWatchlisted={watchlist.includes(stock.id)}
          />
        ))}
      </div>
      
      {/* Empty State */}
      {sortedStocks.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 dark:text-gray-400">No stocks match your search criteria.</p>
          <button 
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-200"
            onClick={() => {
              setSearchTerm('');
              setSelectedSector('');
              setSortBy('alphabetical');
            }}
          >
            Clear Filters
          </button>
        </div>
      )}
    </div>
  );
};

export default StocksExplore;