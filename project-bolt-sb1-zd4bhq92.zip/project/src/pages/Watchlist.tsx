import React, { useState } from 'react';
import { Bookmark, X, Bell, PlusCircle, MoreHorizontal, AlertCircle } from 'lucide-react';
import StockCard from '../components/common/StockCard';
import { mockWatchlist, mockStocks } from '../data/mockData';

const Watchlist: React.FC = () => {
  const [watchlistItems, setWatchlistItems] = useState(mockWatchlist);
  
  // Find full stock data for watchlist items
  const watchlistStocks = watchlistItems.map(item => {
    const stock = mockStocks.find(s => s.id === item.stockId);
    return { ...item, stock };
  });
  
  const removeFromWatchlist = (id: string) => {
    setWatchlistItems(watchlistItems.filter(item => item.id !== id));
  };
  
  // Mock state for alert modal
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [selectedStockId, setSelectedStockId] = useState<string | null>(null);
  
  const openAlertModal = (stockId: string) => {
    setSelectedStockId(stockId);
    setShowAlertModal(true);
  };
  
  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center">
          <Bookmark className="h-6 w-6 text-blue-600 dark:text-blue-500 mr-2" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Watchlist</h1>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium transition-colors duration-200">
          <PlusCircle className="h-4 w-4" /> Add New Stock
        </button>
      </div>
      
      {/* Empty State */}
      {watchlistStocks.length === 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-8 border border-gray-100 dark:border-gray-700 text-center">
          <div className="flex justify-center mb-4">
            <Bookmark className="h-12 w-12 text-gray-400 dark:text-gray-500" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Your watchlist is empty</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            Add stocks to your watchlist to track their performance and receive alerts.
          </p>
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium transition-colors duration-200">
            Browse Stocks
          </button>
        </div>
      )}
      
      {/* Watchlist Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {watchlistStocks.map(item => (
          <div key={item.id} className="relative">
            {item.stock && (
              <div className="group">
                <div className="absolute top-2 right-2 z-10 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <button 
                    onClick={() => openAlertModal(item.stockId)}
                    className="p-1 rounded-full bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 shadow-sm"
                    aria-label="Set price alert"
                  >
                    <Bell className="h-4 w-4" />
                  </button>
                  <button 
                    className="p-1 rounded-full bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 shadow-sm"
                    aria-label="More options"
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </button>
                  <button 
                    onClick={() => removeFromWatchlist(item.id)}
                    className="p-1 rounded-full bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 shadow-sm"
                    aria-label="Remove from watchlist"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                
                {item.alertPrice && (
                  <div className="absolute top-2 left-2 z-10 rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-800 dark:bg-amber-900/30 dark:text-amber-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" /> Alert: ${item.alertPrice}
                  </div>
                )}
                
                <StockCard 
                  stock={item.stock} 
                  onViewDetails={() => console.log('View details:', item.stockId)}
                  isWatchlisted={true}
                />
                
                {item.notes && (
                  <div className="mt-2 text-xs text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 p-2 rounded-md">
                    <span className="font-medium">Note:</span> {item.notes}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Price Alert Modal (simplified) */}
      {showAlertModal && (
        <div className="fixed inset-0 bg-black/50 dark:bg-black/70 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Set Price Alert</h3>
              <button 
                onClick={() => setShowAlertModal(false)}
                className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Alert me when price reaches
              </label>
              <div className="flex items-center">
                <span className="text-gray-500 dark:text-gray-400 mr-2">$</span>
                <input 
                  type="number" 
                  className="block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:text-white sm:text-sm"
                  placeholder="Enter price"
                />
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <button 
                onClick={() => setShowAlertModal(false)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-md font-medium hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium">
                Set Alert
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Watchlist;