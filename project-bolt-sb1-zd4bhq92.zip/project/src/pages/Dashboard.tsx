import React from 'react';
import { TrendingUp, Newspaper, Zap, BarChart, FileText } from 'lucide-react';
import MarketOverview from '../components/dashboard/MarketOverview';
import NewsCard from '../components/common/NewsCard';
import PredictionCard from '../components/common/PredictionCard';
import MarketTrendCard from '../components/dashboard/MarketTrendCard';
import StockCard from '../components/common/StockCard';
import FinancialReports from '../components/reports/FinancialReports';
import { mockNews, mockPredictions, mockMarketTrends, mockStocks } from '../data/mockData';

const Dashboard: React.FC = () => {
  const trendingStocks = mockStocks.slice(0, 4);
  
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Market Dashboard</h1>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Market data as of {new Date().toLocaleDateString('en-US', { 
            month: 'long', 
            day: 'numeric', 
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })}
        </div>
      </div>
      
      {/* Financial Reports Section */}
      <section>
        <div className="flex items-center mb-4">
          <FileText className="h-5 w-5 text-blue-500 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Financial Reports</h2>
        </div>
        <FinancialReports />
      </section>
      
      {/* Market Overview Section */}
      <section>
        <MarketOverview />
      </section>
      
      {/* Smart Predictions */}
      <section>
        <div className="flex items-center mb-4">
          <Zap className="h-5 w-5 text-amber-500 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Smart Predictions</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {mockPredictions.map(prediction => (
            <PredictionCard key={prediction.stockId} prediction={prediction} />
          ))}
        </div>
      </section>
      
      {/* Market Trends */}
      <section>
        <div className="flex items-center mb-4">
          <TrendingUp className="h-5 w-5 text-indigo-500 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Market Trends</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {mockMarketTrends.map(trend => (
            <MarketTrendCard key={trend.id} trend={trend} />
          ))}
        </div>
      </section>
      
      {/* Trending Stocks */}
      <section>
        <div className="flex items-center mb-4">
          <BarChart className="h-5 w-5 text-blue-500 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Trending Stocks</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {trendingStocks.map(stock => (
            <StockCard 
              key={stock.id} 
              stock={stock} 
              onAddToWatchlist={() => console.log('Add to watchlist:', stock.id)}
              onViewDetails={() => console.log('View details:', stock.id)}
            />
          ))}
        </div>
      </section>
      
      {/* Latest Market News */}
      <section>
        <div className="flex items-center mb-4">
          <Newspaper className="h-5 w-5 text-green-500 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Latest Market News</h2>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {mockNews.map(news => (
            <NewsCard key={news.id} news={news} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;