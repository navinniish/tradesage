import React, { useState } from 'react';
import { PieChart, Wallet, DollarSign, TrendingUp, TrendingDown, ArrowRight } from 'lucide-react';
import { mockPortfolio, mockStocks } from '../data/mockData';

const Portfolio: React.FC = () => {
  const [timeRange, setTimeRange] = useState('1W');
  
  // Map holding data to actual stock data
  const portfolioWithStocks = mockPortfolio.holdings.map(holding => {
    const stock = mockStocks.find(s => s.id === holding.stockId);
    return { ...holding, stock };
  });
  
  // Calculate sector allocation
  const sectorAllocation = portfolioWithStocks.reduce((acc, holding) => {
    const sector = holding.stock?.sector || 'Unknown';
    const value = holding.currentValue;
    
    if (!acc[sector]) {
      acc[sector] = 0;
    }
    
    acc[sector] += value;
    return acc;
  }, {} as Record<string, number>);
  
  // Convert to percentage and array format for display
  const sectorAllocationArray = Object.entries(sectorAllocation).map(([sector, value]) => ({
    sector,
    value,
    percentage: (value / mockPortfolio.totalValue) * 100
  }));
  
  // Sort by value (descending)
  sectorAllocationArray.sort((a, b) => b.value - a.value);
  
  // Generate sector colors
  const sectorColors = [
    'bg-blue-500',
    'bg-green-500',
    'bg-purple-500',
    'bg-amber-500',
    'bg-red-500',
    'bg-indigo-500',
    'bg-pink-500',
    'bg-teal-500'
  ];
  
  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Portfolio</h1>
        <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium transition-colors duration-200 flex items-center gap-2">
          <DollarSign className="h-4 w-4" /> Add Funds
        </button>
      </div>
      
      {/* Portfolio Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-5 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center text-gray-500 dark:text-gray-400 mb-2">
            <Wallet className="h-5 w-5 mr-2" />
            <span className="text-sm">Total Value</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 dark:text-white">
            ${mockPortfolio.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Initial Investment: ${mockPortfolio.totalInvestment.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-5 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center text-gray-500 dark:text-gray-400 mb-2">
            <TrendingUp className="h-5 w-5 mr-2" />
            <span className="text-sm">Total Return</span>
          </div>
          <div className="flex items-center">
            <div className="text-2xl font-bold text-green-600 dark:text-green-500">
              +${mockPortfolio.totalReturn.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="ml-2 bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400 px-2 py-1 rounded text-xs font-medium">
              +{mockPortfolio.totalReturnPercent.toFixed(2)}%
            </div>
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            All time
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-5 border border-gray-100 dark:border-gray-700">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center text-gray-500 dark:text-gray-400 mb-2">
                <PieChart className="h-5 w-5 mr-2" />
                <span className="text-sm">Sector Allocation</span>
              </div>
              {sectorAllocationArray.slice(0, 2).map((item, index) => (
                <div key={index} className="flex items-center text-xs mt-1">
                  <div className={`h-3 w-3 rounded-full ${sectorColors[index % sectorColors.length]} mr-2`}></div>
                  <span className="text-gray-700 dark:text-gray-300">{item.sector}</span>
                  <span className="ml-1 text-gray-500 dark:text-gray-400">{item.percentage.toFixed(1)}%</span>
                </div>
              ))}
              <div className="text-xs mt-1 text-blue-600 dark:text-blue-400 flex items-center">
                View All <ArrowRight className="h-3 w-3 ml-1" />
              </div>
            </div>
            <div className="h-16 w-16 rounded-full border-4 border-gray-100 dark:border-gray-700 relative">
              {/* Mini pie chart visualization */}
              {sectorAllocationArray.map((item, index) => {
                const rotate = index === 0 ? 0 : sectorAllocationArray.slice(0, index).reduce((acc, curr) => acc + curr.percentage, 0) * 3.6;
                const size = item.percentage * 3.6;
                return (
                  <div 
                    key={index}
                    className={`absolute inset-0 rounded-full ${sectorColors[index % sectorColors.length]}`}
                    style={{ 
                      clipPath: `polygon(50% 50%, 50% 0%, ${size < 180 ? `${50 + 50 * Math.sin(size * Math.PI/180)}% ${50 - 50 * Math.cos(size * Math.PI/180)}%` : '100% 0%, 100% 100%, 0% 100%, 0% 0%'})`,
                      transform: `rotate(${rotate}deg)`
                    }}
                  ></div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
      
      {/* Performance Chart */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-5 border border-gray-100 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-medium text-gray-900 dark:text-white">Performance</h2>
          <div className="flex space-x-1">
            {['1D', '1W', '1M', '3M', 'YTD', '1Y', 'All'].map(range => (
              <button
                key={range}
                className={`px-2 py-1 text-xs rounded ${
                  timeRange === range
                    ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 font-medium'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
                onClick={() => setTimeRange(range)}
              >
                {range}
              </button>
            ))}
          </div>
        </div>
        
        {/* Chart Placeholder */}
        <div className="h-64 w-full bg-gray-50 dark:bg-gray-700 rounded flex items-center justify-center mb-4">
          <div className="text-gray-400 dark:text-gray-500">
            Performance chart visualization would appear here
          </div>
        </div>
      </div>
      
      {/* Holdings Table */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-5 border-b border-gray-100 dark:border-gray-700">
          <h2 className="font-medium text-gray-900 dark:text-white">My Holdings</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full table-auto">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Stock</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Quantity</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Avg. Price</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Current Price</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Market Value</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Return</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
              {portfolioWithStocks.map(holding => (
                <tr key={holding.id} className="hover:bg-gray-50 dark:hover:bg-gray-750">
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white">{holding.stock?.symbol}</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">{holding.stock?.name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-gray-700 dark:text-gray-300">
                    {holding.quantity}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-gray-700 dark:text-gray-300">
                    ${holding.averageBuyPrice.toFixed(2)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-gray-700 dark:text-gray-300">
                    ${holding.stock?.price.toFixed(2)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right font-medium text-gray-900 dark:text-white">
                    ${holding.currentValue.toFixed(2)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right">
                    <div className={`inline-flex items-center ${holding.returnPercent >= 0 ? 'text-green-600 dark:text-green-500' : 'text-red-600 dark:text-red-500'}`}>
                      {holding.returnPercent >= 0 ? 
                        <TrendingUp className="h-4 w-4 mr-1" /> : 
                        <TrendingDown className="h-4 w-4 mr-1" />
                      }
                      <span>
                        {holding.returnPercent >= 0 ? '+' : ''}{holding.returnPercent.toFixed(2)}%
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-3">Trade</button>
                    <button className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-300">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Portfolio;